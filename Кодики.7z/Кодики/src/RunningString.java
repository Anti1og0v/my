import java.util.Scanner;

public class RunningString {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите слово для бегущей строки:");
        String word = scanner.nextLine();

        while (true) {
            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < 20; j++) {
                    if (j >= i && j < i + word.length()) {
                        System.out.print(word.charAt(j - i));
                    } else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}