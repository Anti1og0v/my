import javax.swing.JOptionPane;

public class Gray {

    public static void main(String[] args) {
        // Получаем ввод от пользователя
        String input = JOptionPane.showInputDialog(null,
                "Введите число (десятичное или код Грея) для преобразования:",
                "Конвертер кода Грея",
                JOptionPane.INFORMATION_MESSAGE);

        try {
            // Пытаемся преобразовать ввод в десятичное число
            int decimalNumber = Integer.parseInt(input, 10);
            String grayCode = toGrayCode(decimalNumber);
            JOptionPane.showMessageDialog(null,
                    "Десятичное: " + decimalNumber + "\nКод Грея: " + grayCode,
                    "Результат преобразования",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            try {
                // Если ввод не является десятичным числом, пытаемся преобразовать его в код Грея
                int grayCode = Integer.parseInt(input, 2);
                int decimalNumber = fromGrayCode(grayCode);
                JOptionPane.showMessageDialog(null,
                        "Код Грея: " + input + "\nДесятичное: " + decimalNumber,
                        "Результат преобразования",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException f) {
                // Если ввод не является ни десятичным числом, ни кодом Грея, выводим ошибку
                JOptionPane.showMessageDialog(null,
                        "Неверный ввод. Пожалуйста, введите десятичное число или код Грея.",
                        "Ошибка",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Метод для преобразования десятичного числа в код Грея
    public static String toGrayCode(int decimalNumber) {
        return Integer.toBinaryString(decimalNumber ^ (decimalNumber >>> 1));
    }

    // Метод для преобразования кода Грея в десятичное число
    public static int fromGrayCode(int grayCode) {
        int decimalNumber = grayCode;
        while ((grayCode & 1)!= 0) {
            grayCode >>= 1;
            decimalNumber ^= grayCode;
        }
        return decimalNumber;
    }
}